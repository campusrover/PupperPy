import argparse
import io
import time
import os.path

from edgetpu.detection.engine import DetectionEngine
from edgetpu.utils import dataset_utils
from imutils.video import VideoStream
import imutils
from PIL import Image
from PIL import ImageDraw
import numpy as np
import picamera
#import cv2

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
            '--model', help='File path of Tflite model. Detection SSD model (must have post-processing operator).', required=True)
    parser.add_argument('--labels', help='File path of label file.', required=True)
    parser.add_argument('--confidence', type=float, default=0.3, help='Minimum probability to filter low probability results')
    parser.add_argument('--keep_aspect_ratio', action='store_true',
            help=(
                'keep the image aspect ratio when down-sampling the image by adding '
                'black pixel padding (zeros) on bottom or right. '
                'By default the image is resized and reshaped without cropping. This '
                'option should be the same as what is applied on input images during '
                'model training. Otherwise the accuracy may be affected and the '
                'bounding box of detection result may be stretched.'))
    print("Parsing arguments ...")
    args = parser.parse_args()
    print("Setting label file...")
    labels = dataset_utils.read_label_file(args.labels) if args.labels else None
    print("Setting coral object detection model...")
    engine = DetectionEngine(args.model)
    #print("Starting VideoStream...")
    #vs = VideoStream(src=0,usePiCamera=True).start()
    
    count = 0
    with picamera.PiCamera() as camera:
        camera.resolution = (640, 480)
        camera.framerate = 30
        _, height, width, _ = engine.get_input_tensor_shape()
        #camera.start_preview()
        time.sleep(2)
        try:
            stream = io.BytesIO()
            for _ in camera.capture_continuous(
                    stream, format='jpeg', use_video_port=True, resize=(width,height)):
                count+=1
                print(str(count))
                stream.truncate()
                stream.seek(0)
                #print(stream)
                #image = Image.open(stream)
                #draw = ImageDraw.Draw(image)
                streamValue = stream.getvalue()
                input_tensor = np.frombuffer(streamValue, dtype=np.uint8)
                image = Image.frombuffer('RGBA', (width,height), streamValue)
                draw = ImageDraw.Draw(image)
                start_ms = time.time()
                #results = engine.detect_with_input_tensor(input_tensor, threshold=0.1, top_k=3)
                results = engine.detect_with_image(image, threshold=0.1, top_k=3, keep_aspect_ratio=True, relative_coord=False)
                for res in results:
                    print('------------------------------')
                    if labels:
                        print(labels[res.label_id])
                    print('score = ', res.score)
                    box = res.bounding_box.flatten().tolist()
                    print('box = ', box)
                    draw.rectangle(box, outline='red')
                    #o = camera.add_overlay(image.tobytes())
                    #camera.remove_overlay(o)
                if not results:
                    print('No objects detected.')
                o = camera.add_overlay(image.tobytes(), format='jpeg')
                time.sleep(.2)
                camera.remove_overlay(o)
                #stream.truncate(0)
        finally:
            camera.stop_preview()
    """
    while True:
        frame = vs.read()
        frame = imutils.resize(frame,width=500)
        orig = frame.copy()

        frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        frame = Image.fromarray(frame)

        start = time.time()
        results = engine.DetectWithImage(frame, threshold=args.confidence, 
                    keep_aspect_ratio=True, relative_coord=False)
        end = time.time()

        # loop over the results
        for r in results:
            box = r.bounding_box.flatten().astype("int")
            (startX, startY, endX, endY) = box
            label = labels[r.label_id]

            # draw the bounding box and label on the image
            cv2.rectangle(orig, (startX, startY), (endX, endY), (0, 255, 0), 2)
            y = startY - 15 if startY - 15 > 15 else startY + 15
            text = "{}: {:.2f}%".format(label, r.score*100)
            cv2.putText(orig, text, (startX, y), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 255, 0), 2)

        # show the output frame and wait for a key press
        cv2.imshow("Frame", orig)
        key = cv2.waitKey(1)

        if key == ord("q"):
            break

cv2.destroyAllWindows()
vs.stop()
    """
if __name__ == "__main__":
    main()
